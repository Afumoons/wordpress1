<?php
/**
 * The template used for displaying slider
 *
 * @package Solid_Construction
 */
?>

<?php
/**
 * solid_construction_slider hook
 * @hooked solid_construction_featured_slider - 10
 */
do_action( 'solid_construction_slider' );
